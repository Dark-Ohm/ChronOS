import type { ReactNode } from "react"
import { PanelShell } from "@/components/panel/panel-shell"
import { RailShowcase } from "@/components/panel/rail-showcase"
import { FilesTab } from "@/components/panel/tabs/files-tab"
import { EditorTab } from "@/components/panel/tabs/editor-tab"
import { TerminalTab } from "@/components/panel/tabs/terminal-tab"
import { SettingsTab } from "@/components/panel/tabs/settings-tab"
import { BindsTab } from "@/components/panel/tabs/binds-tab"
import { darkPalette, lightPalette } from "@/components/panel/theme"

function Frame({
  n,
  title,
  note,
  scheme = "dark",
  children,
}: {
  n: string
  title: string
  note: string
  scheme?: "dark" | "light"
  children: ReactNode
}) {
  return (
    <figure className="flex flex-col gap-3">
      <figcaption className="flex items-baseline gap-3">
        <span className="font-mono text-xs text-neutral-500">{n}</span>
        <span className="text-sm font-medium text-neutral-200">{title}</span>
        <span
          className="rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider"
          style={
            scheme === "dark"
              ? { borderColor: "#3a3a4a", color: "#8b8ba0" }
              : { borderColor: "#d6d9e0", color: "#8c8fa1", backgroundColor: "#e6e9ef" }
          }
        >
          {scheme === "dark" ? "Dark" : "Light C"}
        </span>
      </figcaption>
      <p className="max-w-[560px] text-[13px] leading-relaxed text-neutral-500">{note}</p>
      <div className="w-fit">{children}</div>
    </figure>
  )
}

export default function Page() {
  return (
    <main className="min-h-screen bg-[#0f0f17] px-6 py-12 md:px-12">
      <div className="mx-auto max-w-6xl">
        <header className="mb-12 flex flex-col gap-3">
          <span className="font-mono text-xs uppercase tracking-[0.2em] text-neutral-500">
            Claude Design · 2026-07-24
          </span>
          <h1 className="text-3xl font-semibold text-balance text-neutral-100 md:text-4xl">
            Shell-IDE Right Panel — Tab Container
          </h1>
          <p className="max-w-2xl text-pretty text-[15px] leading-relaxed text-neutral-400">
            The System Sidebar becomes the first of ten tabs in an IDE-style container. A fixed
            vertical icon-rail (VS Code Activity Bar model) switches views inside a full-height,
            560&nbsp;px layer-shell panel. Editor, terminal, and file tree are painted with the same
            role system as the rest of the shell — no separate editor palette.
          </p>
        </header>

        <div className="flex flex-col gap-16">
          <Frame
            n="01"
            title="Files"
            note="VS Code-style tree in our palette/fonts. Rail on the left with all 10 glyphs; System (01) is not the active glyph — Files (02) is. Git status tints the filename (yellow = modified, green = added, blue = untracked)."
          >
            <PanelShell palette={darkPalette} active="files">
              <FilesTab />
            </PanelShell>
          </Frame>

          <Frame
            n="02"
            title="Editor"
            note="Kate-style: open-file tabs on top (view.rs active with an unsaved dot, others closable), muted mono line numbers, a block cursor on the active line, and general syntax coloring drawn from the shared status/accent roles."
          >
            <PanelShell palette={darkPalette} active="editor">
              <EditorTab />
            </PanelShell>
          </Frame>

          <Frame
            n="03"
            title="Terminal"
            note="Embedded PTY view inside the tab — mono type on the darkest layer, colored prompt, and a solid block cursor on the final prompt line."
          >
            <PanelShell palette={darkPalette} active="terminal">
              <TerminalTab />
            </PanelShell>
          </Frame>

          <Frame
            n="04"
            title="MCP settings"
            note="Form archetype shared by the ACP / MCP / LSP / API-provider tabs: one row per entry with a status dot, name + endpoint (mono), a status word, and an enable/disable toggle."
          >
            <PanelShell palette={darkPalette} active="mcp">
              <SettingsTab />
            </PanelShell>
          </Frame>

          <Frame
            n="05"
            title="Hyprland binds"
            note="Live bind → action table (updates on hyprland.lua change, no manual refresh). Key combos render as keycap capsules on an elevated fill; the dispatcher sits under each action in mono."
          >
            <PanelShell palette={darkPalette} active="binds">
              <BindsTab />
            </PanelShell>
          </Frame>

          <Frame
            n="06"
            title="Files"
            scheme="light"
            note="Frame 01 on Light C to check icon-rail and tree contrast on the light scheme — same role table, not a separate IDE theme."
          >
            <PanelShell palette={lightPalette} active="files">
              <FilesTab />
            </PanelShell>
          </Frame>

          <Frame
            n="07"
            title="Icon-rail — full glyph set"
            note="All 10 rail glyphs at scale with their labels, in fixed order. Active tab gets the accent bar on the left plus a slightly lighter fill; inactive glyphs sit at text.muted."
          >
            <RailShowcase palette={darkPalette} />
          </Frame>
        </div>
      </div>
    </main>
  )
}
