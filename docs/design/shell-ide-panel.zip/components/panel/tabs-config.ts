import {
  Gauge,
  FolderTree,
  FileCode,
  SquareTerminal,
  Cable,
  Blocks,
  Braces,
  KeyRound,
  SlidersHorizontal,
  Keyboard,
  type LucideIcon,
} from "lucide-react"

export type PanelTabId =
  | "system"
  | "files"
  | "editor"
  | "terminal"
  | "acp"
  | "mcp"
  | "lsp"
  | "api"
  | "editor-settings"
  | "binds"

export type PanelTab = {
  id: PanelTabId
  label: string
  icon: LucideIcon
}

/** Order is fixed by the user. */
export const PANEL_TABS: PanelTab[] = [
  { id: "system", label: "System", icon: Gauge },
  { id: "files", label: "Files", icon: FolderTree },
  { id: "editor", label: "Editor", icon: FileCode },
  { id: "terminal", label: "Terminal", icon: SquareTerminal },
  { id: "acp", label: "ACP settings", icon: Cable },
  { id: "mcp", label: "MCP settings", icon: Blocks },
  { id: "lsp", label: "LSP settings", icon: Braces },
  { id: "api", label: "API providers", icon: KeyRound },
  { id: "editor-settings", label: "Editor settings", icon: SlidersHorizontal },
  { id: "binds", label: "Hyprland binds", icon: Keyboard },
]
