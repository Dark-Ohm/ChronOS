import { PANEL_TABS, type PanelTabId } from "./tabs-config"

export function IconRail({ active }: { active: PanelTabId }) {
  return (
    <nav
      aria-label="Panel tabs"
      className="flex w-11 shrink-0 flex-col items-center gap-1 border-r py-2"
      style={{
        backgroundColor: "var(--bg-tertiary)",
        borderColor: "var(--panel-border)",
      }}
    >
      {PANEL_TABS.map((tab) => {
        const isActive = tab.id === active
        const Icon = tab.icon
        return (
          <button
            key={tab.id}
            type="button"
            aria-label={tab.label}
            aria-current={isActive ? "page" : undefined}
            title={tab.label}
            className="relative flex h-9 w-9 items-center justify-center rounded-md transition-colors"
            style={{
              backgroundColor: isActive ? "var(--interactive-hover)" : "transparent",
              color: isActive ? "var(--text-primary)" : "var(--text-muted)",
            }}
          >
            {isActive && (
              <span
                aria-hidden
                className="absolute left-[-8px] top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-full"
                style={{ backgroundColor: "var(--accent-primary)" }}
              />
            )}
            <Icon size={20} strokeWidth={1.75} />
          </button>
        )
      })}
    </nav>
  )
}
