import type { CSSProperties } from "react"

export type Palette = {
  bgPrimary: string
  bgSecondary: string
  bgTertiary: string
  bgElevated: string
  textPrimary: string
  textSecondary: string
  textMuted: string
  textDisabled: string
  accentPrimary: string
  accentHover: string
  statusSuccess: string
  statusError: string
  statusWarning: string
  statusInfo: string
  /** subtle interactive hover fill (translucent) */
  interactiveHover: string
  /** hairline border color */
  border: string
}

/** Canonical dark table from the brief (Catppuccin Mocha roles). */
export const darkPalette: Palette = {
  bgPrimary: "#1e1e2e",
  bgSecondary: "#25253b",
  bgTertiary: "#181825",
  bgElevated: "#313244",
  textPrimary: "#cdd6f4",
  textSecondary: "#a6adc8",
  textMuted: "#6c7086",
  textDisabled: "#45475a",
  accentPrimary: "#007acc",
  accentHover: "#cba6f7",
  statusSuccess: "#a6e3a1",
  statusError: "#f38ba8",
  statusWarning: "#f9e2af",
  statusInfo: "#89b4fa",
  interactiveHover: "rgba(205, 214, 244, 0.06)",
  border: "#313244",
}

/** Light C — the standard light table (Catppuccin Latte roles), not an IDE-specific theme. */
export const lightPalette: Palette = {
  bgPrimary: "#eff1f5",
  bgSecondary: "#e6e9ef",
  bgTertiary: "#dce0e8",
  bgElevated: "#ccd0da",
  textPrimary: "#4c4f69",
  textSecondary: "#5c5f77",
  textMuted: "#8c8fa1",
  textDisabled: "#bcc0cc",
  accentPrimary: "#1e66f5",
  accentHover: "#8839ef",
  statusSuccess: "#40a02b",
  statusError: "#d20f39",
  statusWarning: "#df8e1d",
  statusInfo: "#04a5e5",
  interactiveHover: "rgba(76, 79, 105, 0.06)",
  border: "#bcc0cc",
}

/** Expose the palette as CSS custom properties for use with Tailwind arbitrary values. */
export function paletteVars(p: Palette): CSSProperties {
  return {
    "--bg-primary": p.bgPrimary,
    "--bg-secondary": p.bgSecondary,
    "--bg-tertiary": p.bgTertiary,
    "--bg-elevated": p.bgElevated,
    "--text-primary": p.textPrimary,
    "--text-secondary": p.textSecondary,
    "--text-muted": p.textMuted,
    "--text-disabled": p.textDisabled,
    "--accent-primary": p.accentPrimary,
    "--accent-hover": p.accentHover,
    "--status-success": p.statusSuccess,
    "--status-error": p.statusError,
    "--status-warning": p.statusWarning,
    "--status-info": p.statusInfo,
    "--interactive-hover": p.interactiveHover,
    "--panel-border": p.border,
  } as CSSProperties
}
