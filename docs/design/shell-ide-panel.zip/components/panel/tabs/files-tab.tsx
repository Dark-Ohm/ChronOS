import {
  ChevronRight,
  ChevronDown,
  Folder,
  FolderOpen,
  FileCode,
  FileBraces,
  FileText,
  FileCog,
  Braces,
} from "lucide-react"
import type { LucideIcon } from "lucide-react"

type GitStatus = "modified" | "added" | "untracked" | undefined

type Node = {
  name: string
  depth: number
  kind: "folder-open" | "folder" | "file"
  icon: LucideIcon
  iconColor?: string
  git?: GitStatus
  active?: boolean
}

// git status → filename color role
function nameColor(git: GitStatus, active: boolean) {
  if (git === "modified") return "var(--status-warning)"
  if (git === "added") return "var(--status-success)"
  if (git === "untracked") return "var(--status-info)"
  return active ? "var(--text-primary)" : "var(--text-secondary)"
}

const RUST = "#e06c4b"
const TOML = "#9ca0b0"

const TREE: Node[] = [
  { name: "crates", depth: 0, kind: "folder-open", icon: FolderOpen },
  { name: "app", depth: 1, kind: "folder-open", icon: FolderOpen },
  { name: "src", depth: 2, kind: "folder-open", icon: FolderOpen },
  { name: "side_panel_right", depth: 3, kind: "folder-open", icon: FolderOpen },
  { name: "view.rs", depth: 4, kind: "file", icon: FileCode, iconColor: RUST, git: "modified", active: true },
  { name: "tabs.rs", depth: 4, kind: "file", icon: FileCode, iconColor: RUST, git: "added" },
  { name: "mod.rs", depth: 4, kind: "file", icon: FileCode, iconColor: RUST },
  { name: "side_panel_left", depth: 3, kind: "folder", icon: Folder },
  { name: "main.rs", depth: 2, kind: "file", icon: FileCode, iconColor: RUST },
  { name: "services", depth: 1, kind: "folder-open", icon: FolderOpen },
  { name: "src", depth: 2, kind: "folder-open", icon: FolderOpen },
  { name: "hermes_acp", depth: 3, kind: "folder", icon: Folder },
  { name: "registry.rs", depth: 3, kind: "file", icon: FileCode, iconColor: RUST, git: "modified" },
  { name: "config", depth: 0, kind: "folder-open", icon: FolderOpen },
  { name: "hyprland.lua", depth: 1, kind: "file", icon: Braces, iconColor: "var(--status-info)", git: "untracked" },
  { name: "theme.toml", depth: 1, kind: "file", icon: FileCog, iconColor: TOML },
  { name: "Cargo.toml", depth: 0, kind: "file", icon: FileCog, iconColor: TOML, git: "modified" },
  { name: "package.json", depth: 0, kind: "file", icon: FileBraces, iconColor: "var(--status-warning)" },
  { name: "README.md", depth: 0, kind: "file", icon: FileText, iconColor: "var(--text-muted)" },
]

export function FilesTab() {
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center px-3 py-1.5">
        <span
          className="text-[10px] font-semibold uppercase tracking-[0.12em]"
          style={{ color: "var(--text-muted)" }}
        >
          shell-ide
        </span>
      </div>
      <ul className="flex-1 overflow-y-auto pb-2 text-[13px] leading-none">
        {TREE.map((node, i) => {
          const Icon = node.icon
          const isFolder = node.kind !== "file"
          const Chevron = node.kind === "folder-open" ? ChevronDown : ChevronRight
          return (
            <li
              key={`${node.name}-${i}`}
              className="relative flex h-[26px] items-center gap-1.5 pr-3"
              style={{
                paddingLeft: 8 + node.depth * 14,
                backgroundColor: node.active ? "var(--bg-elevated)" : "transparent",
                boxShadow: node.active ? "inset 2px 0 0 var(--accent-primary)" : undefined,
              }}
            >
              {isFolder ? (
                <Chevron size={12} strokeWidth={2} style={{ color: "var(--text-muted)" }} className="shrink-0" />
              ) : (
                <span className="w-3 shrink-0" />
              )}
              <Icon
                size={15}
                strokeWidth={1.75}
                className="shrink-0"
                style={{ color: node.iconColor ?? "var(--status-info)" }}
              />
              <span
                className="truncate font-sans"
                style={{ color: nameColor(node.git, !!node.active), fontWeight: isFolder ? 500 : 400 }}
              >
                {node.name}
              </span>
              {node.git && (
                <span
                  className="ml-auto font-mono text-[10px]"
                  style={{ color: nameColor(node.git, false) }}
                >
                  {node.git === "modified" ? "M" : node.git === "added" ? "A" : "U"}
                </span>
              )}
            </li>
          )
        })}
      </ul>
    </div>
  )
}
