import { Radio } from "lucide-react"

type Bind = { keys: string[]; action: string; dispatcher: string }

const BINDS: Bind[] = [
  { keys: ["SUPER", "Return"], action: "Launch terminal", dispatcher: "exec, kitty" },
  { keys: ["SUPER", "Q"], action: "Close active window", dispatcher: "killactive" },
  { keys: ["SUPER", "Space"], action: "App launcher", dispatcher: "exec, anyrun" },
  { keys: ["SUPER", "E"], action: "Toggle right panel", dispatcher: "exec, shell-ide" },
  { keys: ["SUPER", "F"], action: "Toggle fullscreen", dispatcher: "fullscreen, 0" },
  { keys: ["SUPER", "V"], action: "Toggle floating", dispatcher: "togglefloating" },
  { keys: ["SUPER", "1"], action: "Workspace 1", dispatcher: "workspace, 1" },
  { keys: ["SUPER", "SHIFT", "1"], action: "Move to workspace 1", dispatcher: "movetoworkspace, 1" },
  { keys: ["SUPER", "H"], action: "Focus left", dispatcher: "movefocus, l" },
  { keys: ["SUPER", "L"], action: "Focus right", dispatcher: "movefocus, r" },
]

function Cap({ children }: { children: string }) {
  return (
    <kbd
      className="inline-flex h-[22px] min-w-[22px] items-center justify-center rounded border px-1.5 font-mono text-[11px] font-medium"
      style={{
        backgroundColor: "var(--bg-elevated)",
        borderColor: "var(--panel-border)",
        color: "var(--text-primary)",
        boxShadow: "0 1px 0 rgba(0,0,0,0.35)",
      }}
    >
      {children}
    </kbd>
  )
}

export function BindsTab() {
  return (
    <div className="flex h-full flex-col">
      {/* live indicator */}
      <div
        className="flex items-center gap-2 border-b px-3 py-2"
        style={{ borderColor: "var(--panel-border)" }}
      >
        <Radio size={13} strokeWidth={2} style={{ color: "var(--status-success)" }} />
        <span className="font-mono text-[11px]" style={{ color: "var(--text-muted)" }}>
          live · watching hyprland.lua
        </span>
        <span className="ml-auto font-mono text-[11px]" style={{ color: "var(--text-muted)" }}>
          {BINDS.length} binds
        </span>
      </div>

      <ul className="flex-1 overflow-y-auto">
        {BINDS.map((bind, i) => (
          <li
            key={i}
            className="flex items-center gap-3 border-b px-3 py-2.5"
            style={{ borderColor: "var(--panel-border)" }}
          >
            <div className="flex shrink-0 items-center gap-1">
              {bind.keys.map((k, j) => (
                <span key={j} className="flex items-center gap-1">
                  {j > 0 && (
                    <span className="text-[10px]" style={{ color: "var(--text-muted)" }}>
                      +
                    </span>
                  )}
                  <Cap>{k}</Cap>
                </span>
              ))}
            </div>
            <div className="flex min-w-0 flex-1 flex-col gap-0.5 text-right">
              <span className="truncate font-sans text-[12.5px]" style={{ color: "var(--text-primary)" }}>
                {bind.action}
              </span>
              <span className="truncate font-mono text-[11px]" style={{ color: "var(--text-muted)" }}>
                {bind.dispatcher}
              </span>
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}
