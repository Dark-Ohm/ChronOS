import { FileCode, X } from "lucide-react"

type Tok = { t: string; c?: string }

// syntax color roles (kept within the shared status/accent palette — no separate editor palette)
const KW = "var(--accent-hover)" // keywords
const FN = "var(--status-info)" // functions / types
const STR = "var(--status-success)" // strings
const NUM = "var(--status-warning)" // numbers
const CMT = "var(--text-muted)" // comments
const TXT = "var(--text-primary)" // plain

const LINES: Tok[][] = [
  [{ t: "// side_panel_right — tab container view", c: CMT }],
  [],
  [{ t: "use ", c: KW }, { t: "gpui::", c: TXT }, { t: "prelude", c: FN }, { t: "::*;", c: TXT }],
  [{ t: "use ", c: KW }, { t: "crate::tabs::", c: TXT }, { t: "PanelTab", c: FN }, { t: ";", c: TXT }],
  [],
  [{ t: "pub fn ", c: KW }, { t: "build_panel", c: FN }, { t: "(active: ", c: TXT }, { t: "PanelTab", c: FN }, { t: ") -> ", c: TXT }, { t: "impl IntoElement", c: FN }, { t: " {", c: TXT }],
  [{ t: "    let ", c: KW }, { t: "rail", c: TXT }, { t: " = ", c: TXT }, { t: "IconRail", c: FN }, { t: "::", c: TXT }, { t: "new", c: FN }, { t: "(", c: TXT }, { t: "10", c: NUM }, { t: ");", c: TXT }],
  [{ t: "    rail.", c: TXT }, { t: "set_width", c: FN }, { t: "(", c: TXT }, { t: "46", c: NUM }, { t: ");", c: TXT }],
  [],
  [{ t: "    let ", c: KW }, { t: "content", c: TXT }, { t: " = ", c: TXT }, { t: "match ", c: KW }, { t: "active {", c: TXT }],
  [{ t: "        PanelTab::", c: TXT }, { t: "Files", c: FN }, { t: " => ", c: TXT }, { t: "file_tree", c: FN }, { t: "(),", c: TXT }],
  [{ t: "        PanelTab::", c: TXT }, { t: "Editor", c: FN }, { t: " => ", c: TXT }, { t: "editor_view", c: FN }, { t: "(),", c: TXT }],
  [{ t: "        _ => ", c: TXT }, { t: "placeholder", c: FN }, { t: "(", c: TXT }, { t: '"soon"', c: STR }, { t: "),", c: TXT }],
  [{ t: "    };", c: TXT }],
  [],
  [{ t: "    div", c: FN }, { t: "().", c: TXT }, { t: "flex", c: FN }, { t: "().", c: TXT }, { t: "child", c: FN }, { t: "(rail).", c: TXT }, { t: "child", c: FN }, { t: "(content)", c: TXT }],
  [{ t: "}", c: TXT }],
]

const openTabs = [
  { name: "view.rs", active: true, unsaved: true },
  { name: "tabs.rs", active: false, unsaved: false },
  { name: "registry.rs", active: false, unsaved: false },
]

export function EditorTab() {
  return (
    <div className="flex h-full flex-col">
      {/* open file tabs */}
      <div
        className="flex shrink-0 items-stretch border-b"
        style={{ backgroundColor: "var(--bg-tertiary)", borderColor: "var(--panel-border)" }}
      >
        {openTabs.map((tab) => (
          <div
            key={tab.name}
            className="group flex items-center gap-2 border-r px-3 py-2"
            style={{
              borderColor: "var(--panel-border)",
              backgroundColor: tab.active ? "var(--bg-primary)" : "transparent",
              boxShadow: tab.active ? "inset 0 2px 0 var(--accent-primary)" : undefined,
            }}
          >
            <FileCode size={13} strokeWidth={1.75} style={{ color: "#e06c4b" }} />
            <span
              className="font-mono text-[12px]"
              style={{ color: tab.active ? "var(--text-primary)" : "var(--text-muted)" }}
            >
              {tab.name}
            </span>
            {tab.unsaved ? (
              <span
                className="h-2 w-2 rounded-full"
                style={{ backgroundColor: "var(--text-secondary)" }}
                aria-label="unsaved"
              />
            ) : (
              <X size={13} strokeWidth={2} style={{ color: "var(--text-muted)" }} />
            )}
          </div>
        ))}
      </div>

      {/* code area */}
      <div className="min-h-0 flex-1 overflow-auto" style={{ backgroundColor: "var(--bg-primary)" }}>
        <div className="font-mono text-[12.5px] leading-[1.55]">
          {LINES.map((line, i) => {
            const isActiveLine = i === 6
            return (
              <div
                key={i}
                className="flex"
                style={{ backgroundColor: isActiveLine ? "var(--interactive-hover)" : "transparent" }}
              >
                <span
                  className="select-none px-3 text-right"
                  style={{ minWidth: 46, color: "var(--text-disabled)" }}
                >
                  {i + 1}
                </span>
                <span className="whitespace-pre pr-4" style={{ color: TXT }}>
                  {line.length === 0 ? " " : line.map((tok, j) => (
                    <span key={j} style={{ color: tok.c ?? TXT }}>
                      {tok.t}
                    </span>
                  ))}
                  {isActiveLine && (
                    <span
                      className="ml-px inline-block h-[15px] w-[7px] translate-y-[3px]"
                      style={{ backgroundColor: "var(--text-primary)" }}
                      aria-hidden
                    />
                  )}
                </span>
              </div>
            )
          })}
        </div>
      </div>

      {/* status strip */}
      <div
        className="flex shrink-0 items-center justify-between border-t px-3 py-1 font-mono text-[10px]"
        style={{
          backgroundColor: "var(--bg-tertiary)",
          borderColor: "var(--panel-border)",
          color: "var(--text-muted)",
        }}
      >
        <span>Rust · UTF-8 · LF</span>
        <span>Ln 7, Col 34</span>
      </div>
    </div>
  )
}
