import { Plus } from "lucide-react"

type Status = "connected" | "error" | "disabled"

type Row = {
  name: string
  detail: string
  status: Status
  enabled: boolean
}

const ROWS: Row[] = [
  { name: "filesystem", detail: "npx @mcp/filesystem · stdio", status: "connected", enabled: true },
  { name: "git", detail: "npx @mcp/git · stdio", status: "connected", enabled: true },
  { name: "postgres", detail: "127.0.0.1:5432 · sse", status: "connected", enabled: true },
  { name: "linear", detail: "https://mcp.linear.app · http", status: "error", enabled: true },
  { name: "context7", detail: "https://mcp.context7.com · http", status: "connected", enabled: true },
  { name: "puppeteer", detail: "npx @mcp/puppeteer · stdio", status: "disabled", enabled: false },
]

function statusColor(s: Status) {
  if (s === "connected") return "var(--status-success)"
  if (s === "error") return "var(--status-error)"
  return "var(--text-disabled)"
}

function statusLabel(s: Status) {
  if (s === "connected") return "connected"
  if (s === "error") return "error"
  return "disabled"
}

function Toggle({ on }: { on: boolean }) {
  return (
    <span
      className="relative inline-flex h-[18px] w-8 shrink-0 items-center rounded-full transition-colors"
      style={{ backgroundColor: on ? "var(--accent-primary)" : "var(--bg-elevated)" }}
      role="switch"
      aria-checked={on}
    >
      <span
        className="absolute h-3.5 w-3.5 rounded-full transition-transform"
        style={{
          backgroundColor: on ? "#ffffff" : "var(--text-muted)",
          transform: on ? "translateX(16px)" : "translateX(3px)",
        }}
      />
    </span>
  )
}

export function SettingsTab() {
  return (
    <div className="flex h-full flex-col">
      {/* connection summary */}
      <div
        className="flex items-center justify-between border-b px-3 py-2.5"
        style={{ borderColor: "var(--panel-border)" }}
      >
        <div className="flex flex-col gap-0.5">
          <span className="text-[13px] font-semibold font-sans" style={{ color: "var(--text-primary)" }}>
            Model Context Protocol
          </span>
          <span className="font-mono text-[11px]" style={{ color: "var(--text-muted)" }}>
            5 active · 1 error
          </span>
        </div>
        <button
          type="button"
          className="flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-[12px] font-medium font-sans"
          style={{ backgroundColor: "var(--accent-primary)", color: "#ffffff" }}
        >
          <Plus size={14} strokeWidth={2.25} />
          Add server
        </button>
      </div>

      {/* rows */}
      <ul className="flex-1 overflow-y-auto">
        {ROWS.map((row) => (
          <li
            key={row.name}
            className="flex items-center gap-3 border-b px-3 py-2.5"
            style={{ borderColor: "var(--panel-border)" }}
          >
            <span
              className="h-2 w-2 shrink-0 rounded-full"
              style={{
                backgroundColor: statusColor(row.status),
                boxShadow: row.status === "connected" ? "0 0 6px var(--status-success)" : undefined,
              }}
            />
            <div className="flex min-w-0 flex-1 flex-col gap-0.5">
              <span className="truncate font-mono text-[13px]" style={{ color: "var(--text-primary)" }}>
                {row.name}
              </span>
              <span className="truncate font-mono text-[11px]" style={{ color: "var(--text-muted)" }}>
                {row.detail}
              </span>
            </div>
            <span
              className="w-16 shrink-0 text-right font-sans text-[11px] capitalize"
              style={{ color: statusColor(row.status) }}
            >
              {statusLabel(row.status)}
            </span>
            <Toggle on={row.enabled} />
          </li>
        ))}
      </ul>
    </div>
  )
}
