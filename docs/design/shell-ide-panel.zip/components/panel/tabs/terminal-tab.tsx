type Line = { parts: { t: string; c?: string }[] }

const P = "var(--status-success)" // prompt user
const D = "var(--status-info)" // directory / host
const M = "var(--text-muted)" // dim
const T = "var(--text-primary)" // output
const W = "var(--status-warning)"
const E = "var(--status-error)"

const LINES: Line[] = [
  { parts: [{ t: "~/shell-ide", c: D }, { t: " on ", c: M }, { t: " main", c: "var(--accent-hover)" }] },
  { parts: [{ t: "❯ ", c: P }, { t: "cargo build --release", c: T }] },
  { parts: [{ t: "   Compiling ", c: M }, { t: "app ", c: T }, { t: "v0.3.1", c: M }] },
  { parts: [{ t: "   Compiling ", c: M }, { t: "services ", c: T }, { t: "v0.3.1", c: M }] },
  { parts: [{ t: "warning", c: W }, { t: ": unused variable: ", c: T }, { t: "`rail_w`", c: D }] },
  { parts: [{ t: "    Finished ", c: P }, { t: "release ", c: T }, { t: "in 12.84s", c: M }] },
  { parts: [] },
  { parts: [{ t: "~/shell-ide", c: D }, { t: " on ", c: M }, { t: " main", c: "var(--accent-hover)" }] },
  { parts: [{ t: "❯ ", c: P }, { t: "./target/release/app --panel right", c: T }] },
  { parts: [{ t: "[panel] ", c: D }, { t: "layer-shell surface acquired (560x1080)", c: T }] },
  { parts: [{ t: "[panel] ", c: D }, { t: "restored 3 editor sessions", c: T }] },
  { parts: [{ t: "[acp]   ", c: D }, { t: "hermes connected ", c: T }, { t: "127.0.0.1:8787", c: M }] },
  { parts: [] },
  { parts: [{ t: "~/shell-ide", c: D }, { t: " on ", c: M }, { t: " main", c: "var(--accent-hover)" }] },
  { parts: [{ t: "❯ ", c: P }] },
]

export function TerminalTab() {
  return (
    <div className="h-full overflow-auto p-3 font-mono text-[12.5px] leading-[1.6]" style={{ backgroundColor: "var(--bg-tertiary)" }}>
      {LINES.map((line, i) => (
        <div key={i} className="flex flex-wrap whitespace-pre">
          {line.parts.length === 0 ? (
            <span> </span>
          ) : (
            line.parts.map((p, j) => (
              <span key={j} style={{ color: p.c ?? T }}>
                {p.t}
              </span>
            ))
          )}
          {i === LINES.length - 1 && (
            <span
              className="inline-block h-[15px] w-[8px] translate-y-[2px]"
              style={{ backgroundColor: "var(--text-primary)" }}
              aria-hidden
            />
          )}
        </div>
      ))}
    </div>
  )
}
