import { PANEL_TABS } from "./tabs-config"
import { paletteVars, type Palette } from "./theme"

export function RailShowcase({ palette }: { palette: Palette }) {
  return (
    <div
      style={paletteVars(palette)}
      className="flex overflow-hidden rounded-lg font-sans shadow-2xl ring-1 ring-black/40"
    >
      {/* the rail itself, enlarged */}
      <div
        className="flex flex-col items-center gap-2 py-4"
        style={{ backgroundColor: "var(--bg-tertiary)", width: 72 }}
      >
        {PANEL_TABS.map((tab, i) => {
          const Icon = tab.icon
          const isActive = i === 1
          return (
            <div
              key={tab.id}
              className="relative flex h-12 w-12 items-center justify-center rounded-lg"
              style={{
                backgroundColor: isActive ? "var(--interactive-hover)" : "transparent",
                color: isActive ? "var(--text-primary)" : "var(--text-muted)",
              }}
            >
              {isActive && (
                <span
                  className="absolute left-[-10px] top-1/2 h-6 w-[3px] -translate-y-1/2 rounded-full"
                  style={{ backgroundColor: "var(--accent-primary)" }}
                />
              )}
              <Icon size={24} strokeWidth={1.75} />
            </div>
          )
        })}
      </div>

      {/* legend */}
      <ul className="flex flex-col justify-center gap-2 py-4 pl-4 pr-6" style={{ backgroundColor: "var(--bg-primary)" }}>
        {PANEL_TABS.map((tab, i) => (
          <li key={tab.id} className="flex h-12 items-center gap-2">
            <span
              className="font-mono text-[11px]"
              style={{ color: "var(--text-disabled)", minWidth: 18 }}
            >
              {String(i + 1).padStart(2, "0")}
            </span>
            <span
              className="text-[13px]"
              style={{ color: i === 1 ? "var(--text-primary)" : "var(--text-secondary)" }}
            >
              {tab.label}
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}
