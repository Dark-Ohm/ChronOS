import type { ReactNode } from "react"
import { IconRail } from "./icon-rail"
import { PANEL_TABS, type PanelTabId } from "./tabs-config"
import { paletteVars, type Palette } from "./theme"

export function PanelShell({
  palette,
  active,
  headerRight,
  children,
  height = 720,
}: {
  palette: Palette
  active: PanelTabId
  headerRight?: ReactNode
  children: ReactNode
  height?: number
}) {
  const tab = PANEL_TABS.find((t) => t.id === active)!
  const Icon = tab.icon
  return (
    <div
      style={{ ...paletteVars(palette), width: 560, height }}
      className="flex overflow-hidden rounded-lg font-sans shadow-2xl ring-1 ring-black/40"
    >
      <IconRail active={active} />
      <div className="flex min-w-0 flex-1 flex-col" style={{ backgroundColor: "var(--bg-primary)" }}>
        {/* Panel header */}
        <header
          className="flex h-10 shrink-0 items-center justify-between border-b px-3"
          style={{ backgroundColor: "var(--bg-tertiary)", borderColor: "var(--panel-border)" }}
        >
          <div className="flex items-center gap-2">
            <Icon size={14} strokeWidth={2} style={{ color: "var(--text-secondary)" }} />
            <span
              className="text-[11px] font-semibold uppercase tracking-[0.08em]"
              style={{ color: "var(--text-secondary)" }}
            >
              {tab.label}
            </span>
          </div>
          {headerRight}
        </header>
        <div className="min-h-0 flex-1">{children}</div>
      </div>
    </div>
  )
}
